// profileApp.js - Main entry point for profile page JavaScript

// Import utility functions
import { showMessage, clearMessageContainers, hideAllAddEditForms } from './utils.js';

// Import setup functions from other modules
// Note: We will set up these listeners here in profileApp.js
// import { setupProfilePicListeners } from './profilePic.js'; // No longer importing setup functions directly
// import { setupBioListeners } from './bio.js'; // No longer importing setup functions directly
import { setupExperienceListeners, fetchAndRenderExperienceForModal } from './experienceSections.js';
import { setupSkillsInterestsListeners } from './skillsInterests.js';
// Assuming mainPageDisplay.js exists and exports fetchAndRenderMainPageData
import { fetchAndRenderMainPageData } from './mainPageDisplay.js'; // This now returns profile data including flags
import { setupTabListeners } from './tabs.js';
// Import setupDetailsPopup and setprofileDataCache from detailsPopup.js
import { setupDetailsPopup, getProfileDataCache } from './detailsPopup.js';


// Get references to top-level elements
const editProfileButton = document.getElementById('edit-profile-button');
const profileSettingsPopup = document.getElementById('profile-settings-popup');
const closeButton = document.querySelector('#profile-settings-popup .close-button'); // Ensure targeting settings modal close button

// Get references for the new Profile Setup Wizard modal
const profileWizardPopup = document.getElementById('profile-wizard-popup');
const wizardCloseButton = document.getElementById('wizard-close-button');
const wizardTitle = document.getElementById('wizard-title');
const wizardMessagesContainer = document.getElementById('wizard-messages');
const wizardStepsContainer = document.getElementById('wizard-steps');
const wizardSteps = document.querySelectorAll('.wizard-step'); // Get all wizard step divs

// Wizard navigation buttons
const wizardStartButton = document.getElementById('wizard-start-button');
const wizardSkipButton = document.getElementById('wizard-skip-button');
const wizardPrevButtons = document.querySelectorAll('.wizard-navigation .secondary'); // All "Previous" buttons
const wizardNextButtons = document.querySelectorAll('.wizard-navigation .wizard-button:not(.secondary)'); // All "Next" buttons

// Wizard step specific elements (for reusing settings logic)
// Profile Picture elements (used in both settings and wizard)
const currentProfilePicContainer = document.querySelector('.current-profile-pic-container'); // In settings modal
const wizardProfilePictureSection = document.getElementById('wizard-profile-picture-section'); // In wizard modal
const wizardProfileImage = document.getElementById('wizard-profile-image'); // Image in wizard
const wizardUploadPicButton = document.getElementById('wizard-upload-pic-button'); // Button in wizard (Removed from HTML, but keeping reference for logic)
const wizardUploadProfilePicForm = document.getElementById('wizard-upload-profile-pic-form'); // Form in wizard
const wizardProfilePicFileInput = wizardUploadProfilePicForm ? wizardUploadProfilePicForm.querySelector('input[type="file"]') : null; // File input in wizard
const wizardProfilePictureMessagesContainer = document.getElementById('wizard-profile-picture-messages'); // Messages in wizard
const wizardProfilePicClickableArea = document.querySelector('.wizard-profile-pic-clickable'); // Added clickable area for profile pic

// Bio elements (used in both settings and wizard)
const editBioForm = document.getElementById('edit-bio-form'); // In settings modal
const bioTextarea = document.getElementById('bio'); // In settings modal
const bioMessageContainer = document.getElementById('bio-messages'); // In settings modal
const wizardBioSection = document.getElementById('wizard-bio-section'); // In wizard modal
const wizardEditBioForm = document.getElementById('wizard-edit-bio-form'); // Form in wizard
const wizardBioTextarea = document.getElementById('wizard-bio'); // Textarea in wizard
const wizardBioMessagesContainer = document.getElementById('wizard-bio-messages'); // Messages in wizard


// Work Experience elements (used in both settings and wizard)
const addEditWorkExperienceForm = document.getElementById('add-edit-work-experience-form'); // In settings modal
const wizardWorkExperienceSection = document.getElementById('wizard-work-experience-section'); // In wizard modal
const wizardAddWorkExperienceForm = document.getElementById('wizard-add-edit-work-experience-form'); // Form in wizard
const wizardWorkExperienceMessagesContainer = document.getElementById('wizard-work-experience-messages'); // Messages in wizard
const wizardAddWorkExperienceButton = document.getElementById('wizard-add-work-experience-button'); // Added button reference


// Projects elements (used in both settings and wizard)
const addEditProjectsForm = document.getElementById('add-edit-projects-form'); // In settings modal
const wizardProjectsSection = document.getElementById('wizard-projects-section'); // In wizard modal
const wizardAddProjectsForm = document.getElementById('wizard-add-edit-projects-form'); // Form in wizard
const wizardProjectsMessagesContainer = document.getElementById('wizard-projects-messages'); // Messages in wizard
const wizardAddProjectButton = document.getElementById('wizard-add-project-button'); // Added button reference


// Education elements (used in both settings and wizard)
const addEditEducationForm = document.getElementById('add-edit-education-form'); // In settings modal
const wizardEducationSection = document.getElementById('wizard-education-section'); // In wizard modal
const wizardAddEducationForm = document.getElementById('wizard-add-edit-education-form'); // Form in wizard
const wizardEducationMessagesContainer = document.getElementById('wizard-education-messages'); // Messages in wizard
const wizardAddEducationButton = document.getElementById('wizard-add-education-button'); // Added button reference


// Skills elements (used in both settings and wizard)
const editSkillsForm = document.getElementById('edit-skills-form'); // In settings modal
const skillsTextarea = document.getElementById('skills-textarea'); // In settings modal
const skillsMessageContainer = document.querySelector('#skills-settings .settings-messages'); // In settings modal
const wizardSkillsSection = document.getElementById('wizard-skills-section'); // In wizard modal
const wizardEditSkillsForm = document.getElementById('wizard-edit-skills-form'); // Form in wizard
const wizardSkillsTextarea = document.getElementById('wizard-skills-textarea'); // Textarea in wizard
const wizardSkillsMessagesContainer = document.getElementById('wizard-skills-messages'); // Messages in wizard


// Interests elements (used in both settings and wizard)
const editInterestsForm = document.getElementById('edit-interests-form'); // In settings modal
const interestsTextarea = document.getElementById('interests-textarea'); // In settings modal
const interestsMessageContainer = document.querySelector('#interests-settings .settings-messages'); // In settings modal
const wizardInterestsSection = document.getElementById('wizard-interests-section'); // In wizard modal
const wizardEditInterestsForm = document.getElementById('wizard-edit-interests-form'); // Form in wizard
const wizardInterestsTextarea = document.getElementById('wizard-interests-textarea'); // Textarea in wizard
const wizardInterestsMessagesContainer = document.getElementById('wizard-interests-messages'); // Messages in wizard


// Languages elements (used in both settings and wizard - Employee Specific)
const editLanguagesForm = document.getElementById('edit-languages-form'); // In settings modal
const languagesTextarea = document.getElementById('languages-textarea'); // In settings modal
const languagesMessageContainer = document.querySelector('#languages-settings .settings-messages'); // In settings modal
const wizardLanguagesSection = document.getElementById('wizard-languages-section'); // In wizard modal
const wizardEditLanguagesForm = document.getElementById('wizard-edit-languages-form'); // Form in wizard
const wizardLanguagesTextarea = document.getElementById('wizard-languages-textarea'); // Textarea in wizard
const wizardLanguagesMessagesContainer = document.getElementById('wizard-languages-messages'); // Messages in wizard

// Main profile languages display element
const mainLanguagesDisplay = document.getElementById('main-languages-display');


const wizardGoToProfileButton = document.getElementById('wizard-go-to-profile');


// Get all message containers for clearing (include wizard messages)
const profilePicMessageContainer = document.getElementById('profile-picture-messages'); // In settings modal
const settingsMessageContainers = document.querySelectorAll('#profile-settings-popup .settings-messages'); // All message containers in settings sections
const allMessageContainers = [
    profilePicMessageContainer,
    bioMessageContainer, // From settings modal
    wizardMessagesContainer, // Generic wizard messages
    wizardProfilePictureMessagesContainer, // Wizard specific
    wizardBioMessagesContainer, // Wizard specific
    wizardWorkExperienceMessagesContainer, // Wizard specific
    wizardProjectsMessagesContainer, // Wizard specific
    wizardEducationMessagesContainer, // Wizard specific
    wizardSkillsMessagesContainer, // Wizard specific
    wizardInterestsMessagesContainer, // Wizard specific
    wizardLanguagesMessagesContainer, // Wizard specific
    ...Array.from(settingsMessageContainers) // From settings modal sections
].filter(Boolean); // Combine and filter out nulls


// Get all add/edit forms for hiding (include wizard forms if they exist)
const addEditForms = document.querySelectorAll('.add-edit-form'); // Forms in settings modal
const allFormsToHide = [...Array.from(addEditForms)];
if (wizardUploadProfilePicForm) allFormsToHide.push(wizardUploadProfilePicForm);
if (wizardEditBioForm) allFormsToHide.push(wizardEditBioForm);
if (wizardAddWorkExperienceForm) allFormsToHide.push(wizardAddWorkExperienceForm);
if (wizardAddProjectsForm) allFormsToHide.push(wizardAddProjectsForm); // Added wizard project form
if (wizardAddEducationForm) allFormsToHide.push(wizardAddEducationForm); // Added wizard education form


// Get the current user ID from the data attribute on the body
const currentUserId = document.body.dataset.currentUserId;
const viewedUserId = document.body.dataset.viewedUserId; // Also get viewed user ID
const currentUserType = document.body.dataset.currentUserType; // Get user type


// Function to hide all profile picture related nested popups/forms (defined here as it's used by modal close)
function hideProfilePicActions() {
    // Assuming these elements are only in the settings modal
    const settingsProfilePicChoicePopup = document.getElementById('profile-pic-choice-popup');
    const settingsUploadForm = document.getElementById('upload-profile-pic-form');

    if (settingsProfilePicChoicePopup) settingsProfilePicChoicePopup.style.display = 'none';
    if (settingsUploadForm) settingsUploadForm.style.display = 'none';

    // Also hide wizard specific forms if they exist
     if (wizardUploadProfilePicForm) wizardUploadProfilePicForm.style.display = 'none';
}


// --- Modal Control Functions (Apply to both Settings and Wizard) ---
// Function to open a modal and add the class to the body
function openModal(modalElement) {
    if (modalElement) {
        modalElement.style.display = 'block';
        document.body.classList.add('modal-open'); // Add class to body
    }
}

// Function to close a modal and remove the class from the body
function closeModal(modalElement) {
     if (modalElement) {
        modalElement.style.display = 'none';
        // Only remove modal-open if no other modals are open
        if (!document.querySelector('.modal[style*="display: block"]')) {
             document.body.classList.remove('modal-open'); // Remove class from body
        }
     }
     // Clear messages and hide forms for ALL modals when any modal is closed
     clearMessageContainers(allMessageContainers);
     hideProfilePicActions(); // Hide nested forms/popups for both
     hideAllAddEditForms(allFormsToHide); // Hide all add/edit forms for both
     // Clear file inputs if they exist
     const fileInputs = document.querySelectorAll('input[type="file"]');
     fileInputs.forEach(input => {
         if (input) input.value = '';
     });
     // Refresh main page data after closing any modal
     fetchAndRenderMainPageData();
}
// --- End Modal Control Functions ---


// --- Wizard Specific Functions ---
let currentWizardStep = 1;

// Function to mark the wizard as shown in the database
async function markWizardAsShownInDatabase() {
    try {
        const response = await fetch('/api/profile/mark_wizard_shown', {
            method: 'POST', // Use POST as it modifies state
            headers: {
                'Content-Type': 'application/json',
                // Include CSRF token if you are using Flask-WTF or similar
                // 'X-CSRFToken': getCookie('csrf_token') // You'll need a getCookie function
            },
            // No body needed for this simple update
        });

        const data = await response.json();
        if (data.status !== 'success') {
            console.error('Failed to mark wizard as shown in database:', data.message);
            // Optionally show an error message to the user
        } else {
             console.log('Wizard marked as shown in database.');
             // Update the profileData cache if it exists, so subsequent checks are correct
             // (This is a simple approach, a more robust cache might be needed)
             if (window.profileDataCache && window.profileDataCache.user_flags) {
                 window.profileDataCache.user_flags.wizard_shown = true;
             }
        }
    } catch (error) {
        console.error('Error marking wizard as shown:', error);
        // Optionally show an error message to the user
    }
}

// Function to show a specific wizard step based on number or 'finish'
function showWizardStep(stepIdentifier) {
    // Map step identifier to the actual HTML element ID
    let elementId;
    switch (stepIdentifier) {
        case 1:
            elementId = 'wizard-step-1'; // Welcome
            break;
        case 2:
            elementId = 'wizard-step-2'; // Profile Picture
            break;
        case 3:
            elementId = 'wizard-step-3'; // Bio
            break;
        case 4:
            elementId = 'wizard-step-4'; // Work Experience (Employee)
            break;
        case 5:
             elementId = 'wizard-step-5'; // Projects
             break;
        case 6:
             elementId = 'wizard-step-6'; // Education
             break;
        case 7:
             elementId = 'wizard-step-7'; // Skills
             break;
        case 8:
             elementId = 'wizard-step-8'; // Interests
             break;
        case 9:
             elementId = 'wizard-step-9'; // Languages (Employee)
             break;
        case 10:
            elementId = 'wizard-step-10'; // Finish
            break;
        case 'finish': // Allow 'finish' as an alternative way to specify the last step
             elementId = 'wizard-step-10'; // Finish
             stepIdentifier = 10; // Set currentWizardStep to the numerical value
             break;
        default:
            console.error('Unknown wizard step identifier:', stepIdentifier);
            return; // Stop if the identifier is unknown
    }

    wizardSteps.forEach(step => {
        step.style.display = 'none';
    });

    const stepToShow = document.getElementById(elementId);
    if (stepToShow) {
        stepToShow.style.display = 'flex'; // Assuming flex layout for steps
        // Update currentWizardStep to the numerical value for navigation logic
        currentWizardStep = stepIdentifier;
        // Clear messages specific to wizard steps
        clearMessageContainers([
            wizardMessagesContainer,
            wizardProfilePictureMessagesContainer,
            wizardBioMessagesContainer,
            wizardWorkExperienceMessagesContainer,
            wizardProjectsMessagesContainer, // Added
            wizardEducationMessagesContainer, // Added
            wizardSkillsMessagesContainer, // Added
            wizardInterestsMessagesContainer, // Added
            wizardLanguagesMessagesContainer // Added
        ].filter(Boolean)); // Filter out nulls if elements don't exist
        updateWizardTitle(stepIdentifier);
    } else {
         console.error('Wizard step element not found:', elementId);
    }
}


function updateWizardTitle(stepIdentifier) {
    let title = 'Welcome to Your Profile!';
    switch (stepIdentifier) {
        case 2: title = 'Step 1: Add Profile Picture'; break;
        case 3: title = 'Step 2: Write Your Bio'; break;
        case 4: title = 'Step 3: Add Work Experience'; break; // Employee specific
        case 5: title = 'Step 4: Add Projects'; break;
        case 6: title = 'Step 5: Add Education'; break;
        case 7: title = 'Step 6: Add Skills'; break;
        case 8: title = 'Step 7: Add Interests'; break;
        case 9: title = 'Step 8: Add Languages'; break; // Employee specific
        case 10: title = 'Setup Complete!'; break;
    }
    if (wizardTitle) wizardTitle.textContent = title;
}

// Function to save data for the current wizard step if it's a form step
async function saveCurrentWizardStepData() {
    let formToSave = null;
    let messagesContainer = null;
    let apiUrl = null;

    switch (currentWizardStep) {
        case 3: // Bio step
            formToSave = wizardEditBioForm;
            messagesContainer = wizardBioMessagesContainer;
            apiUrl = '/api/profile/update_bio';
            break;
        // Note: Work Experience, Projects, Education have their own submit listeners
        case 7: // Skills step
            formToSave = wizardEditSkillsForm;
            messagesContainer = wizardSkillsMessagesContainer;
            apiUrl = '/api/profile/skills'; // Assuming this endpoint exists
            break;
        case 8: // Interests step
            formToSave = wizardEditInterestsForm;
            messagesContainer = wizardInterestsMessagesContainer;
            apiUrl = '/api/profile/interests'; // Assuming this endpoint exists
            break;
        case 9: // Languages step (Employee specific)
             if (currentUserType === 'employee') {
                formToSave = wizardEditLanguagesForm;
                messagesContainer = wizardLanguagesMessagesContainer;
                apiUrl = '/api/profile/languages'; // Assuming this endpoint exists
             }
            break;
        // Profile picture is handled by file input change, not form submit
        default:
            // No saving needed for this step
            return true; // Indicate success immediately
    }

    if (!formToSave || !apiUrl) {
        // No form to save or API URL for this step (e.g., Welcome, Profile Pic, Finish)
        return true; // Indicate success immediately
    }

    // Prevent default form submission
    // Note: Since buttons are removed, this might be less critical, but good practice
    // if we were triggering a 'submit' event directly.
    // For now, we'll manually collect data and fetch.

    const formData = new FormData(formToSave);

    // Check if the form has data to save (e.g., textarea is not empty)
    let hasData = false;
    for (const [name, value] of formData.entries()) {
        if (value && String(value).trim() !== '') {
            hasData = true;
            break;
        }
    }

    if (!hasData) {
         console.log(`Step ${currentWizardStep}: No data to save.`);
         clearMessageContainers([messagesContainer].filter(Boolean)); // Clear any previous messages
         return true; // Consider it a success if there's nothing to save
    }


    showMessage(messagesContainer, 'info', 'Saving...');

    try {
        const response = await fetch(apiUrl, {
            method: 'POST',
            body: formData,
        });

        const data = await response.json();
        showMessage(messagesContainer, data.status, data.message);

        if (data.status === 'success') {
            console.log(`Step ${currentWizardStep} data saved:`, data);
            // Optionally update the main profile display after saving
            fetchAndRenderMainPageData(); // This will now trigger renderLanguages
            return true; // Indicate success
        } else {
            console.error(`Step ${currentWizardStep} save failed:`, data.message);
            return false; // Indicate failure
        }
    } catch (error) {
        console.error(`Step ${currentWizardStep} save failed:`, error);
        showMessage(messagesContainer, 'error', 'An error occurred while saving.');
        return false; // Indicate failure
    }
}


async function nextWizardStep() {
    // Attempt to save data for the current step before moving on
    const saveSuccessful = await saveCurrentWizardStepData();

    // Only proceed to the next step if the save was successful or if the step didn't require saving
    if (saveSuccessful) {
        // Determine the next step based on the current step and user type
        if (currentWizardStep === 1) {
            showWizardStep(2); // Welcome -> Profile Picture
        } else if (currentWizardStep === 2) {
            showWizardStep(3); // Profile Picture -> Bio
        } else if (currentWizardStep === 3) {
            // Bio -> Work Experience (Employee) or Finish (Employer)
            if (currentUserType === 'employee') {
                showWizardStep(4);
            } else {
                showWizardStep(10); // Go directly to finish for employer
            }
        } else if (currentWizardStep === 4 && currentUserType === 'employee') {
             showWizardStep(5); // Work Experience -> Projects (Employee)
        } else if (currentWizardStep === 5 && currentUserType === 'employee') {
             showWizardStep(6); // Projects -> Education (Employee)
        } else if (currentWizardStep === 6 && currentUserType === 'employee') {
             showWizardStep(7); // Education -> Skills (Employee)
        } else if (currentWizardStep === 7 && currentUserType === 'employee') {
             showWizardStep(8); // Skills -> Interests (Employee)
        } else if (currentWizardStep === 8 && currentUserType === 'employee') {
             showWizardStep(9); // Interests -> Languages (Employee)
        } else if (currentWizardStep === 9 && currentUserType === 'employee') {
            showWizardStep(10); // Languages -> Finish (Employee)
        } else {
            // Default to finish if somehow in an unexpected state or already at finish
            showWizardStep(10);
        }
    } else {
        console.log(`Save failed for step ${currentWizardStep}. Staying on current step.`);
        // The save function already shows an error message, so no need to do it here.
    }
}

function prevWizardStep() {
    // Determine the previous step based on the current step and user type
     if (currentWizardStep === 2) {
        showWizardStep(1); // Profile Picture -> Welcome
    } else if (currentWizardStep === 3) {
        showWizardStep(2); // Bio -> Profile Picture
    } else if (currentWizardStep === 4 && currentUserType === 'employee') {
        showWizardStep(3); // Work Experience -> Bio (Employee)
    } else if (currentWizardStep === 5 && currentUserType === 'employee') {
         showWizardStep(4); // Projects -> Work Experience (Employee)
    } else if (currentWizardStep === 6 && currentUserType === 'employee') {
         showWizardStep(5); // Education -> Projects (Employee)
    } else if (currentWizardStep === 7 && currentUserType === 'employee') {
         showWizardStep(6); // Skills -> Education (Employee)
    } else if (currentWizardStep === 8 && currentUserType === 'employee') {
         showWizardStep(7); // Interests -> Skills (Employee)
    } else if (currentWizardStep === 9 && currentUserType === 'employee') {
         showWizardStep(8); // Languages -> Interests (Employee)
    } else if (currentWizardStep === 10) { // If at finish
        // Go back to the last step depending on user type
        if (currentUserType === 'employee') {
             showWizardStep(9); // Finish -> Languages (Employee)
        } else {
             showWizardStep(3); // Finish -> Bio (Employer)
        }
    } else {
         // Default to step 1 if somehow in an unexpected state
         showWizardStep(1);
    }
}

function skipWizard() {
    // Mark the wizard as shown in the database when the user skips
    markWizardAsShownInDatabase();
    closeModal(profileWizardPopup);
}

function finishWizard() {
    // Mark the wizard as shown in the database when the user finishes
    markWizardAsShownInDatabase();
    closeModal(profileWizardPopup);
}

// Function to render languages on the main profile page
function renderLanguages(languagesString) {
    if (mainLanguagesDisplay) {
        // Wrap the languages string in a strong tag for bolding
        mainLanguagesDisplay.innerHTML = languagesString ? `<strong>${languagesString}</strong>` : '';
         // Add or remove the 'has-languages' class based on whether there are languages
        if (languagesString) {
            mainLanguagesDisplay.classList.add('has-languages');
        } else {
            mainLanguagesDisplay.classList.remove('has-languages');
        }
    }
}


// Optional: Add a way to clear the wizard flag for testing purposes
// You would need a backend endpoint to reset the wizard_shown flag in the database
// window.clearProfileWizardFlag = async () => {
//      try {
//          const response = await fetch('/api/profile/reset_wizard_flag', { method: 'POST' }); // Assuming you create this endpoint
//          const data = await response.json();
//          if (data.status === 'success') {
//              console.log('Wizard flag reset in database.');
//              if (window.profileDataCache && window.profileDataCache.user_flags) {
//                  window.profileDataCache.user_flags.wizard_shown = false; // Update cache
//              }
//          } else {
//               console.error('Failed to reset wizard flag:', data.message);
//          }
//      } catch (error) {
//           console.error('Error resetting wizard flag:', error);
//      }
// };
// --- End Wizard Specific Functions ---


// Setup event listeners once the DOM is fully loaded
document.addEventListener('DOMContentLoaded', async () => { // Made the listener async

    // Setup listeners from other modules
    // Pass the correct fetch callbacks to experienceSections and skillsInterests
    // These callbacks will trigger a refresh of the main page and the settings modal data
    setupExperienceListeners(fetchAndRenderMainPageData, () => fetchAndRenderExperienceForModal(currentUserId, fetchAndRenderMainPageData));
    setupSkillsInterestsListeners(fetchAndRenderMainPageData);
    setupTabListeners();
    setupDetailsPopup(); // Setup the generic details popup

    // Fetch and populate data for the main page when the page loads
    // This fetch will now also get the user_flags including the wizard_shown status from the backend
    fetchAndRenderMainPageData(); // Assuming fetchAndRenderMainPageData returns the profile data
    let profileData = getProfileDataCache();
    // --- Added logging for debugging languages display ---
    console.log('Profile Data fetched:', profileData);
    if (profileData && profileData.additional_data) {
        console.log('Additional Data:', profileData.additional_data);
        console.log('Languages Data:', profileData.additional_data.languages);
    } else {
        console.log('No additional_data found in profileData.');
    }
    // --- End logging ---

    // Render languages on the main profile page after fetching data
    if (profileData && profileData.additional_data && profileData.additional_data.languages) {
        renderLanguages(profileData.additional_data.languages);
    } else {
        renderLanguages(''); // Clear languages if no data
    }


    // --- Check URL for 'open_edit' parameter and open modal/wizard if present ---
    const urlParams = new URLSearchParams(window.location.search);
    const openEditModal = urlParams.get('open_edit');

    // Access the wizard_shown flag from the user_flags JSON object in the fetched data
    const hasWizardBeenShown = profileData && profileData.user_flags && profileData.user_flags.wizard_shown === true;

    // Corrected logic: Check if it's the current user and open_edit is true, then decide wizard or settings
    if (viewedUserId === currentUserId && openEditModal === 'true') {
        if (!hasWizardBeenShown) {
            openModal(profileWizardPopup); // Open the wizard if not shown before
            showWizardStep(1); // Start at the first step
        } else {
            openModal(profileSettingsPopup); // Open the settings modal if wizard has been shown
            // Clear all messages and hide all forms when opening the settings modal
            clearMessageContainers(allMessageContainers);
            hideProfilePicActions();
            hideAllAddEditForms(allFormsToHide);
            // Fetch and populate data specifically for the settings modal
            fetchAndRenderExperienceForModal(currentUserId, fetchAndRenderMainPageData);
        }
        // Optional: Clean up the URL after using the parameter
        // history.replaceState({}, document.title, window.location.pathname);
    }
    // --- End Check URL ---


    // Event listener for opening the profile settings modal button (Keep this for opening via button click)
    if (editProfileButton) {
        editProfileButton.addEventListener('click', () => {
            openModal(profileSettingsPopup); // Open the settings modal
            // Clear all messages and hide all forms when opening the settings modal
            clearMessageContainers(allMessageContainers);
            hideProfilePicActions();
            hideAllAddEditForms(allFormsToHide);
            // Fetch and populate data specifically for the settings modal
            fetchAndRenderExperienceForModal(currentUserId, fetchAndRenderMainPageData);
            // Skills and Interests textareas are pre-populated by Jinja, no extra fetch needed on modal open unless they can be edited by others
        });
    }

    // Event listener for closing the profile settings modal close button
    if (closeButton) {
        closeButton.addEventListener('click', () => {
            closeModal(profileSettingsPopup);
        });
    }

    // Event listener for clicking outside the settings modal to close it
    if (profileSettingsPopup) {
        window.addEventListener('click', (event) => {
            if (event.target == profileSettingsPopup) {
                closeModal(profileSettingsPopup);
            }
        });
    }

    // --- Wizard Event Listeners ---
    if (wizardCloseButton) {
        wizardCloseButton.addEventListener('click', () => {
            // Treat closing the wizard as skipping it for the "show once" logic
            skipWizard();
        });
    }

    if (profileWizardPopup) {
        window.addEventListener('click', (event) => {
            if (event.target == profileWizardPopup) {
                // Treat clicking outside as skipping
                 skipWizard();
            }
        });
    }

    if (wizardStartButton) {
        wizardStartButton.addEventListener('click', () => {
            showWizardStep(2); // Go to Profile Picture step
        });
    }

    if (wizardSkipButton) {
        wizardSkipButton.addEventListener('click', () => {
            skipWizard();
        });
    }

    // "Previous" buttons
    wizardPrevButtons.forEach(button => {
        button.addEventListener('click', () => {
            prevWizardStep();
        });
    });

    // "Next" buttons
    wizardNextButtons.forEach(button => {
        button.addEventListener('click', () => {
             // Trigger next step logic which includes saving
            nextWizardStep();
        });
    });

    // "Go to Profile" button on the finish step
    if (wizardGoToProfileButton) {
        wizardGoToProfileButton.addEventListener('click', () => {
            finishWizard();
        });
    }

    // --- Wizard Step Specific Logic (Reusing Settings Functionality) ---

    // Wizard Profile Picture Upload (Logic adapted from profilePic.js)
    // Trigger file input click when the profile picture area is clicked
    if (wizardProfilePicClickableArea && wizardProfilePicFileInput && wizardProfilePictureMessagesContainer && wizardProfileImage) {
         wizardProfilePicClickableArea.style.cursor = 'pointer'; // Indicate it's clickable
         wizardProfilePicClickableArea.addEventListener('click', () => {
             // Trigger the file input click programmatically
             wizardProfilePicFileInput.click();
         });

         wizardProfilePicFileInput.addEventListener('change', async (event) => {
             const file = event.target.files[0];
             if (!file) {
                 showMessage(wizardProfilePictureMessagesContainer, 'info', 'Profile picture upload canceled.');
                 return;
             }

             showMessage(wizardProfilePictureMessagesContainer, 'info', 'Uploading profile picture...');

             const formData = new FormData();
             formData.append('profile_pic', file);

             try {
                 const response = await fetch('/api/profile/upload_profile_pic', {
                     method: 'POST',
                     body: formData,
                 });

                 const data = await response.json();

                 if (data.status === 'success') {
                     showMessage(wizardProfilePictureMessagesContainer, 'success', data.message);
                     // Update the image source in the wizard
                     wizardProfileImage.src = data.profile_picture_url;
                     // Also update the main profile picture if the user is viewing their own profile
                     if (viewedUserId === currentUserId) {
                          const mainProfilePic = document.querySelector('.profile-pic img');
                          if (mainProfilePic) mainProfilePic.src = data.profile_picture_url;
                     }
                 } else {
                     showMessage(wizardProfilePictureMessagesContainer, 'error', data.message);
                 }
             } catch (error) {
                 console.error('Wizard Upload failed:', error);
                 showMessage(wizardProfilePictureMessagesContainer, 'error', 'An error occurred during upload.');
             } finally {
                 // Clear the file input value regardless of success or failure
                 event.target.value = '';
                 // Hide the upload form visually (it's just a container now)
                 if (wizardUploadProfilePicForm) wizardUploadProfilePicForm.style.display = 'none';
             }
         });
    }

    // Wizard Bio Save (Logic adapted from bio.js) - Now triggered by nextWizardStep
    // We keep the form submit listener but it will now be triggered programmatically by saveCurrentWizardStepData
    if (wizardEditBioForm && wizardBioMessagesContainer && wizardBioTextarea) {
        wizardEditBioForm.addEventListener('submit', async (event) => {
            event.preventDefault(); // Prevent default form submission
            // The saving logic is now handled by saveCurrentWizardStepData
        });
    }

    // Wizard Work Experience Save (Employee Specific) (Logic adapted from experienceSections.js)
    // This form is only present if the user is an employee
    if (wizardAddWorkExperienceForm && wizardWorkExperienceMessagesContainer) {
        wizardAddWorkExperienceForm.addEventListener('submit', async (event) => {
            event.preventDefault(); // Prevent default form submission
            const formData = new FormData(wizardAddWorkExperienceForm);

            showMessage(wizardWorkExperienceMessagesContainer, 'info', 'Saving work experience...');

            try {
                // Use the existing add_work_experience API endpoint
                const response = await fetch('/api/profile/work-experience', {
                    method: 'POST', // Assuming POST for adding
                    body: formData,
                });

                const data = await response.json();
                showMessage(wizardWorkExperienceMessagesContainer, data.status, data.message);

                if (data.status === 'success') {
                    console.log('Work experience added:', data);
                    // Clear the form for potential next entry (though wizard moves on)
                    wizardAddWorkExperienceForm.reset();
                    // Refresh the main page display to show the new entry
                    fetchAndRenderMainPageData();
                    // Optionally hide the form after successful submission
                    wizardAddWorkExperienceForm.style.display = 'none';
                }
            } catch (error) {
                console.error('Wizard Work Experience save failed:', error);
                showMessage(wizardWorkExperienceMessagesContainer, 'error', 'An error occurred while saving work experience.');
            }
        });
    }

    // Wizard Projects Save (Logic adapted from projectsSections.js - assuming similar structure)
     if (wizardAddProjectsForm && wizardProjectsMessagesContainer) {
        wizardAddProjectsForm.addEventListener('submit', async (event) => {
            event.preventDefault(); // Prevent default form submission
            const formData = new FormData(wizardAddProjectsForm);

            showMessage(wizardProjectsMessagesContainer, 'info', 'Saving project...');

            try {
                // Use the existing add_project API endpoint (assuming this exists)
                const response = await fetch('/api/profile/projects', {
                    method: 'POST', // Assuming POST for adding
                    body: formData,
                });

                const data = await response.json();
                showMessage(wizardProjectsMessagesContainer, data.status, data.message);

                if (data.status === 'success') {
                    console.log('Project added:', data);
                    // Clear the form for potential next entry
                    wizardAddProjectsForm.reset();
                    // Refresh the main page display
                    fetchAndRenderMainPageData();
                    // Optionally hide the form after successful submission
                    wizardAddProjectsForm.style.display = 'none';
                }
            } catch (error) {
                console.error('Wizard Project save failed:', error);
                showMessage(wizardProjectsMessagesContainer, 'error', 'An error occurred while saving project.');
            }
        });
    }

    // Wizard Education Save (Logic adapted from educationSections.js - assuming similar structure)
     if (wizardAddEducationForm && wizardEducationMessagesContainer) {
        wizardAddEducationForm.addEventListener('submit', async (event) => {
            event.preventDefault(); // Prevent default form submission
            const formData = new FormData(wizardAddEducationForm);

            showMessage(wizardEducationMessagesContainer, 'info', 'Saving education...');

            try {
                // Use the existing add_education API endpoint (assuming this exists)
                const response = await fetch('/api/profile/education', {
                    method: 'POST', // Assuming POST for adding
                    body: formData,
                });

                const data = await response.json();
                showMessage(wizardEducationMessagesContainer, data.status, data.message);

                if (data.status === 'success') {
                    console.log('Education added:', data);
                    // Clear the form for potential next entry
                    wizardAddEducationForm.reset();
                    // Refresh the main page display
                    fetchAndRenderMainPageData();
                    // Optionally hide the form after successful submission
                    wizardAddEducationForm.style.display = 'none';
                }
            } catch (error) {
                console.error('Wizard Education save failed:', error);
                showMessage(wizardEducationMessagesContainer, 'error', 'An error occurred while saving education.');
            }
        });
    }


    // Wizard Skills Save - Now triggered by nextWizardStep
    if (wizardEditSkillsForm && wizardSkillsMessagesContainer && wizardSkillsTextarea) {
        wizardEditSkillsForm.addEventListener('submit', async (event) => {
            event.preventDefault(); // Prevent default form submission
            // The saving logic is now handled by saveCurrentWizardStepData
        });
    }

    // Wizard Interests Save - Now triggered by nextWizardStep
    if (wizardEditInterestsForm && wizardInterestsMessagesContainer && wizardInterestsTextarea) {
        wizardEditInterestsForm.addEventListener('submit', async (event) => {
            event.preventDefault(); // Prevent default form submission
             // The saving logic is now handled by saveCurrentWizardStepData
        });
    }

    // Wizard Languages Save - Now triggered by nextWizardStep (Employee Specific)
    if (wizardEditLanguagesForm && wizardLanguagesMessagesContainer && wizardLanguagesTextarea) {
        wizardEditLanguagesForm.addEventListener('submit', async (event) => {
            event.preventDefault(); // Prevent default form submission
             // The saving logic is now handled by saveCurrentWizardStepData
        });
    }


    // --- Event Listeners for "Add New" buttons within Wizard Steps ---
    if (wizardAddWorkExperienceButton) {
        wizardAddWorkExperienceButton.addEventListener('click', () => {
            if (wizardAddWorkExperienceForm) {
                hideAllAddEditForms([wizardAddWorkExperienceForm, wizardAddProjectsForm, wizardAddEducationForm].filter(Boolean)); // Hide other forms
                wizardAddWorkExperienceForm.style.display = 'block'; // Show the work experience form
                wizardAddWorkExperienceForm.reset(); // Clear the form for a new entry
                // Clear messages specific to this form
                 clearMessageContainers([wizardWorkExperienceMessagesContainer].filter(Boolean));
            }
        });
    }

     if (wizardAddProjectButton) {
        wizardAddProjectButton.addEventListener('click', () => {
            if (wizardAddProjectsForm) {
                 hideAllAddEditForms([wizardAddWorkExperienceForm, wizardAddProjectsForm, wizardAddEducationForm].filter(Boolean)); // Hide other forms
                wizardAddProjectsForm.style.display = 'block'; // Show the projects form
                wizardAddProjectsForm.reset(); // Clear the form for a new entry
                 // Clear messages specific to this form
                 clearMessageContainers([wizardProjectsMessagesContainer].filter(Boolean));
            }
        });
    }

     if (wizardAddEducationButton) {
        wizardAddEducationButton.addEventListener('click', () => {
            if (wizardAddEducationForm) {
                 hideAllAddEditForms([wizardAddWorkExperienceForm, wizardAddProjectsForm, wizardAddEducationForm].filter(Boolean)); // Hide other forms
                wizardAddEducationForm.style.display = 'block'; // Show the education form
                wizardAddEducationForm.reset(); // Clear the form for a new entry
                 // Clear messages specific to this form
                 clearMessageContainers([wizardEducationMessagesContainer].filter(Boolean));
            }
        });
    }

    // --- Event Listeners for Cancel buttons within Wizard Forms ---
    const wizardCancelButtons = document.querySelectorAll('.wizard-cancel-form-button');
    wizardCancelButtons.forEach(button => {
        button.addEventListener('click', () => {
            // Find the parent form and hide it
            const form = button.closest('form');
            if (form) {
                form.style.display = 'none';
                form.reset(); // Clear the form
                // Clear messages associated with this form
                 const messagesContainer = form.nextElementSibling; // Assuming messages are right after the form
                 if(messagesContainer && messagesContainer.classList.contains('settings-messages')) {
                     clearMessageContainers([messagesContainer]);
                 }
            }
        });
    });


    // Optional: Add a way to clear the wizard flag for testing purposes
    // You would need a backend endpoint to reset the wizard_shown flag in the database
    // window.clearProfileWizardFlag = async () => {
    //      try {
    //          const response = await fetch('/api/profile/reset_wizard_flag', { method: 'POST' }); // Assuming you create this endpoint
    //          const data = await response.json();
    //          if (data.status === 'success') {
    //              console.log('Wizard flag reset in database.');
    //              if (window.profileDataCache && window.profileDataCache.user_flags) {
    //                  window.profileDataCache.user_flags.wizard_shown = false; // Update cache
    //              }
    //          } else {
    //               console.error('Failed to reset wizard flag:', data.message);
    //          }
    //      } catch (error) {
    //           console.error('Error resetting wizard flag:', error);
    //      }
    // };
});
